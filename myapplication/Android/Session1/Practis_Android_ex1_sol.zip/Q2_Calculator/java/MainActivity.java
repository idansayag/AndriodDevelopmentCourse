/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This application simulates a very basic
    calculator with only the next simple supported
    actions: + - * and division. 
================================================= */
package il.co.practis.calculator;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	int action = -1;					// Holds last selection action ID
	double number1;						// Holds first number of calculation
	boolean showingResult = false;		// flag to indicate if clear value 
	// upon first number click

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	/**
	 * Handles all button clicks except for numberic buttons
	 * @param v
	 */
	public void onButtonClick(View v) {

		// get id of clicked button
		Button clickedButton = (Button)v;
		int buttonID = clickedButton.getId();

		switch (buttonID) {
		case R.id.btnDivision:
		case R.id.btnSum:
		case R.id.btnMultiplication:
		case R.id.btnSubtraction:
			setAction(buttonID);
			break;

		case R.id.btnResult:
			findResult(false);
			break;						
		}
	}


	/**
	 * If a numeric button clicked (buttons 0-9), add that number to the
	 * label showing the current number
	 * @param v
	 */
	public void onNumericButtonClick(View v) {

		// get the result label we are going to edit
		TextView textViewResult = (TextView)findViewById(R.id.textViewResult);

		// get the text of the clicked button
		Button clickedNumericButton = (Button)v;
		String buttonText = clickedNumericButton.getText().toString();

		// if in result-show-mode, first numeric click will clear current value
		if (showingResult == true) {
			textViewResult.setText(buttonText);
			showingResult = false;
		} else {
			// else we append current number to the result
			textViewResult.append(buttonText);	
		}		
	}


	/**
	 * Clears all variables and the result label field
	 * @param v
	 */
	public void onClearButtonClick(View v) {
		TextView textViewResult = (TextView)findViewById(R.id.textViewResult);
		textViewResult.setText("");
		action = -1;
		number1 = 0;
		showingResult = false;
	}

	/**
	 * Sets the action to perform between both numbers
	 * @param actionID
	 */
	private void setAction(int actionID) {

		showingResult = false;			// clear the result view flag

		// If same action button was clicked twice, run the calculation
		// with same number
		if (this.action == actionID) {
			findResult(true);
			return;
		}

		// set new action
		this.action = actionID;

		// if the label field has a value, use it as number1, otherwise it
		// will happen when the user selects a different action to perform
		// instead of the one selected before
		TextView textViewResult = (TextView)findViewById(R.id.textViewResult);
		String currentValue = textViewResult.getText().toString();
		if (currentValue.isEmpty() == false) {
			number1 = Double.parseDouble(currentValue);  
			textViewResult.setText("");
		}    	
	}


	/**
	 * Runs the actual calculation
	 * @param sameAction
	 */
	private void findResult(boolean sameAction) {
		double number2;
		double result = 0;

		TextView textViewResult = (TextView)findViewById(R.id.textViewResult);

		if (sameAction == true) {
			number2 = number1;
		} else {
			String currentValue = textViewResult.getText().toString();

			// if no value was provided for number2, such as if the user 
			// clicked action button and then the = button, we use the first
			// number twice
			if (currentValue.isEmpty()) {
				number2 = number1;
			} else {
				number2 = Double.parseDouble(currentValue);
			}
		}

		switch (this.action) {
		case R.id.btnDivision:
			if (number2 == 0) {
				showError("Division by zero is not permitted!");
				onClearButtonClick(null);
				return;
			} else {
				result = number1 / number2;
			}
			break;

		case R.id.btnSum:
			result = number1 + number2;
			break;

		case R.id.btnMultiplication:
			result = number1 * number2;
			break;

		case R.id.btnSubtraction:
			result = number1 - number2;
			break;
		}

		// show result
		this.action = -1;
		textViewResult.setText(result + "");   
		showingResult = true;
	}


	/**
	 * Shows a toast with the provided error message
	 * @param message
	 */
	private void showError(String message) {
		Context context = getApplicationContext();
		Toast toast = Toast.makeText(context, message,
				Toast.LENGTH_SHORT);
		toast.show();
	}
}