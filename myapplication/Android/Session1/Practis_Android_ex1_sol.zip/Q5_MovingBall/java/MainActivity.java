/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This application shows a ball that bounces
    around the screen, changing direction every
    time it hits a wall.    
================================================= */
package il.co.practis.movingball;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.DisplayMetrics;
import android.widget.ImageView;

public class MainActivity extends Activity {

	int screenWidth, screenHeight;			// holds size of the screen
	int deltaX = 1;							// change to do in X coordinate
	int deltaY = -1;						// change to do in Y coordinate
	Timer timer = new Timer();
	Random randomGenerator = new Random();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// obtain screen size		
		getScreenSize();

		// start ball moving timer
		startTimer();

		setContentView(R.layout.activity_main);
	}


	/**
	 * Gets the actual screen size
	 */
	private void getScreenSize() {
		DisplayMetrics metrics = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(metrics);

		screenHeight = metrics.heightPixels;
		screenWidth = metrics.widthPixels;				
	}

	
	/**
	 * Generates a new random angle, in opposite direction of the old one
	 * @param currentAngle
	 * @return
	 */
	private int setNewAngle(int currentAngle) {

		int result = 0;

		// generate random number between 1 and 3		
		result = randomGenerator.nextInt(3) + 1;

		// if old angle is positive, make it now negative
		if (currentAngle > 0) {
			result *= -1;
		}

		return result;
	}

	
	protected void startTimer() {
		timer.scheduleAtFixedRate(new TimerTask() {
			public void run() {
				// signal UI thread to move ball
				mHandler.obtainMessage(1).sendToTarget();
			}
		}, 500, 10);
	}

	
	public Handler mHandler = new Handler(new Handler.Callback() {
		@Override
		public boolean handleMessage(Message msg) {
			// check if ball reached walls, if so set new direction
			ImageView ball = (ImageView)findViewById(R.id.imageViewBall);

			// check X
			if ((ball.getX() <= 0) || (ball.getX() + ball.getWidth() > screenWidth)) {
				deltaX = setNewAngle(deltaX);
			}

			// check Y
			if ((ball.getY() <= 0) || (ball.getY() + ball.getHeight() > screenHeight)) {
				deltaY = setNewAngle(deltaY);
			}

			// move ball
			ball.setX(ball.getX() + deltaX);
			ball.setY(ball.getY() + deltaY);

			return true;
		}
	});
}