/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This is a simple Tic-Tac-Toe game
================================================= */
package il.co.practis.tictactoe;

import java.util.Random;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {

	int[][] gameBoard = new int[3][3];			// holds the game board
	Random randomGenerator = new Random();		// used to generate randoms

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	
	/**
	 * Handles the click of the various images
	 * @param v
	 */
	public void onButtonsClick(View v) {

		// Change image to X
		ImageView clickedImageView = (ImageView)v;        
		clickedImageView.setImageResource(R.drawable.x);

		// update game board with player movement
		updateBoard(clickedImageView.getTag().toString());

		// disable current image so it can't be clicked again
		clickedImageView.setEnabled(false);

		// check if there is a win (If player won the game)
		boolean result = checkWins();
		if (result == true) {
			gameOver(getString(R.string.message_player_won));
			return;
		}

		// let the computer play
		boolean computerPlayed = computerPlay();
		// if computer can't find an empty spot to play, it means this is
		// a draw
		if (computerPlayed == false) {
			gameOver(getString(R.string.message_draw));
			return;
		}

		// check if there is win, meaning if the computer played and won
		result = checkWins();
		if (result == true) {
			gameOver(getString(R.string.message_computer_won));
		}
	}

	
	/**
	 * Shows the provided message and disables the board so no further
	 * movements can be made
	 * @param message
	 */
	private void gameOver(String message) {
		showMessage(message);

		// disable all buttons
		for (int i = 0; i < gameBoard.length; i++) {
			for (int j = 0; j < gameBoard[0].length; j++) {
				int resId = getResources().getIdentifier("imageView" + i + j, "id", getPackageName());
				ImageView imageView = (ImageView)findViewById(resId);
				imageView.setEnabled(false);				
			}
		}
	}

	/**
	 * Updates the gameBoard in memory (represented by a matrix) with latest
	 * player movement
	 * @param tag
	 */
	private void updateBoard(String tag) {
		String[] coordinates = tag.split(",");

		int i = Integer.parseInt(coordinates[0]);
		int j = Integer.parseInt(coordinates[1]);

		gameBoard[i][j] = 1;		
	}

	
	/**
	 * Scans the board to see if it is in a state of victory
	 * @return
	 */
	private boolean checkWins() {

		// check wins in rows and columns
		int sumRow = 0;
		int sumCol = 0;
		for (int i = 0; i < gameBoard.length; i++) {
			for (int j = 0; j < gameBoard[0].length; j++) {
				sumRow += gameBoard[i][j];
				sumCol += gameBoard[j][i];
			}
			if ((Math.abs(sumRow) == 3) || (Math.abs(sumCol) == 3)) {
				return true;
			}
			sumRow = 0;
			sumCol = 0;
		}

		// check wins in diagonal
		int diagonalSum = 0;
		diagonalSum = gameBoard[0][0] + gameBoard[1][1] + gameBoard[2][2];
		if (Math.abs(diagonalSum) == 3) {
			return true;
		}

		// check other diagonal
		diagonalSum = gameBoard[2][0] + gameBoard[1][1] + gameBoard[0][2];
		if (Math.abs(diagonalSum) == 3) {
			return true;
		}

		return false;
	}


	/**
	 * Check if there is an empty place the computer can place his O.
	 * If there isn't - return false.
	 * If there is - find one empty location randomly and mark it with O.	 
	 * @return true if there was a play available
	 */
	private boolean computerPlay() {

		boolean moveFound = false;

		// check if there is an available move
		for (int i = 0; i < gameBoard.length; i++) {
			for (int j = 0; j < gameBoard[0].length; j++) {
				if (gameBoard[i][j] == 0) {
					moveFound = true;
					break;
				}
			}			
		}

		// if there isn't - return false
		if (moveFound == false) return false;

		
		// if we've reached this point, there is a move available.
		// find one for the computer randomly
		boolean foundMove = false;
		do {
			int i = randomGenerator.nextInt(3);
			int j = randomGenerator.nextInt(3);

			if (gameBoard[i][j] == 0) {
				gameBoard[i][j] = -1;
				foundMove = true;
				updateUI(i,j);
			}
		} while (foundMove == false);

		return true;
	}

	
	/**
	 * Update the UI with the move made by the computer. mark it as O.
	 * @param i x coordinate
	 * @param j y coordinate
	 */
	private void updateUI(int i, int j) {
		int resId = getResources().getIdentifier("imageView" + i + j, "id", getPackageName());
		ImageView imageView = (ImageView)findViewById(resId);
		imageView.setImageResource(R.drawable.o);
		imageView.setEnabled(false);
	}

	/**
	 * Shows a toast message with the provided string
	 * @param message Content of the toast to show
	 */
	private void showMessage(String message) {
		Context context = getApplicationContext();
		Toast toast = Toast.makeText(context, message,
				Toast.LENGTH_SHORT);
		toast.show();
	}
}