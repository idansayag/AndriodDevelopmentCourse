/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This application shows the user an image and
    four buttons - up / down / left / right 
    so he could move the image around the screen.
    
    This is a basic exercise of a needed capability
    for future more complex games.
================================================= */
package il.co.practis.movingpicture;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class MainActivity extends Activity {

	private final int MOVE_FACTOR = 10;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	public void onUpButtonClick(View v) {
		moveImage(0, -1);
	}
	
	public void onDownButtonClick(View v) {
		moveImage(0, 1);
	}
	
	public void onLeftButtonClick(View v) {
		moveImage(-1, 0);
	}
	
	public void onRightButtonClick(View v) {
		moveImage(1, 0);
	}

	
	/**
	 * Moves the knight image by the provided changes in the x and y coordinates
	 * @param deltaX
	 * @param deltaY
	 */
	private void moveImage(int deltaX, int deltaY) {
		ImageView knight = (ImageView)findViewById(R.id.imageViewKnight);
		knight.setX(knight.getX() + deltaX * MOVE_FACTOR);
		knight.setY(knight.getY() + deltaY * MOVE_FACTOR);		
	}
}