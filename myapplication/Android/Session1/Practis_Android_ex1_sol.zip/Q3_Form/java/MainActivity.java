/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This application simulates a registration form
    on which several inputs are required and several
    validations are being made to make sure all
    provided information is correct    
================================================= */
package il.co.practis.form;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	/**
	 * Runs all validations required on the form
	 * @param v
	 */
	public void onSubmitClick(View v) {
		
		// validate first name
		String firstName = getFieldText(R.id.editTextFirstName);		
		if (firstName.length() < 3) {
			showError(getString(R.string.first_name_error));
			return;
		}

		// validate last name
		String lastName = getFieldText(R.id.editTextLastName);		
		if (lastName.length() < 3) {
			showError(getString(R.string.last_name_error));
			return;
		}
		
		// validate age field
		String ageAsString = getFieldText(R.id.editTextAge);
		try {
			int ageAsInt = Integer.parseInt(ageAsString);
			if ((ageAsInt < 18) || (ageAsInt > 99)) {
				showError(getString(R.string.age_error));
				return;				
			}			
		} catch (Exception e) {
			showError(getString(R.string.age_error));
			return;
		}

		// validate address
		String address = getFieldText(R.id.editTextAddress);		
		if (address.length() < 5) {
			showError(getString(R.string.address_error));
			return;
		}

		// validate phone
		String phone = getFieldText(R.id.editTextPhone);		
		if (phone.length() < 8) {
			showError(getString(R.string.phone_error));
			return;
		}
		
		// validate gender
		RadioGroup radioGroup = (RadioGroup)findViewById(R.id.myRadioGroup);
		int checkedID = radioGroup.getCheckedRadioButtonId();
		if (checkedID == -1) {
			showError(getString(R.string.gender_error));
			return;			
		}
		
		// if all is OK
		showError(getString(R.string.success_message));
	}
	
	
	/**
	 * Returns the text value of a provided field ID
	 * @param fieldID
	 * @return
	 */
	private String getFieldText(int fieldID) {
		EditText field = (EditText)findViewById(fieldID);
		return field.getText().toString();
	}
	

	/**
	 * Shows a toast with the provided error message
	 * @param message
	 */
	private void showError(String message) {
		Context context = getApplicationContext();
		Toast toast = Toast.makeText(context, message,
				Toast.LENGTH_SHORT);
		toast.show();
	}
}
