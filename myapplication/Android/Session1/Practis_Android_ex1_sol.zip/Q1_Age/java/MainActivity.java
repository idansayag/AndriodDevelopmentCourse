/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This application asks the user for his age,
    and shows a different toast answer according
    to the value provided by the user.
================================================= */
package il.co.practis.age;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    
    /**
     * Handles the click event of the only button in the form.
     * It first parses the value provided by the user, and then
     * show a different message according to the value provided
     * @param v
     */
    public void doDoneClick(View v) {
    	
    	// find text field
    	EditText txtAge = (EditText)findViewById(R.id.txtAge);
    	
    	// get text field value
    	String currentAge = txtAge.getText().toString();
    	
    	try {
    		// try to parse the text field value to an Integer
    		int currentIntAge = Integer.parseInt(currentAge);
    		
    		if (currentIntAge < 0) {
    			showToast(getString(R.string.message_less_than_0));	
    		} else if (currentIntAge < 18){
    			showToast(getString(R.string.message_minor));
    		}else if (currentIntAge < 120) {
    			showToast(getString(R.string.message_adult));
    		} else {
    			showToast(getString(R.string.message_older_than_120));
    		}
    	}
    	catch (Exception e) {
    		showToast(getString(R.string.error_message));    	
    	}
    }
    
    /**
     * Shows a toast message with the provided string
     * @param message Content of the toast to show
     */
    private void showToast(String message) {
    	Context context = getApplicationContext();
        Toast toast = Toast.makeText(context, message,
    											 Toast.LENGTH_SHORT);
        toast.show();
    }
}