/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This App saves all form's fields values and
    recovers them when the App is closed and re-opened
================================================= */
package il.co.practis.sharedpreferences;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		loadValues();
	}


	@Override
	protected void onPause()  {
		super.onPause();

		// Create object to store values privately
		SharedPreferences preferences  = getPreferences(MODE_PRIVATE); 
		SharedPreferences.Editor editor = preferences.edit(); 

		// Get values from the UI   
		EditText txtFirstName = (EditText)findViewById(R.id.editTextFirstName);
		String firstName = txtFirstName.getText().toString();
		EditText txtLastName = (EditText)findViewById(R.id.editTextLastName);
		String lastName = txtLastName.getText().toString();
		RadioButton radioMale = (RadioButton)findViewById(R.id.radioMale);
		RadioButton radioFemale = (RadioButton)findViewById(R.id.radioFemale);
		boolean isMaleChecked = radioMale.isChecked();
		boolean isFemaleChecked = radioFemale.isChecked();
		CheckBox checkBox = (CheckBox)findViewById(R.id.checkBox1);
		boolean isCheckBoxChecked = checkBox.isChecked();

		// Store values  
		editor.putString("firstName", firstName);
		editor.putString("lastName", lastName);
		editor.putBoolean("isMaleChecked", isMaleChecked);
		editor.putBoolean("isFemaleChecked", isFemaleChecked);
		editor.putBoolean("sendChocolate", isCheckBoxChecked);

		// Commit to storage  
		editor.commit(); 
	}

	public void moveToNextScreen(View view) {

		// move to next screen
		Intent intent = new Intent(this, SecondScreen.class);
		startActivity(intent); 
		finish();
	}


	private void loadValues() {
		// Get required storage object
		SharedPreferences preferences = getPreferences(MODE_PRIVATE); 

		// Set the values of the UI   
		EditText firstName = (EditText)findViewById(R.id.editTextFirstName);  
		firstName.setText(preferences.getString("firstName", null));

		EditText lastName = (EditText)findViewById(R.id.editTextLastName);  
		lastName.setText(preferences.getString("lastName", null));

		RadioButton radioMale = (RadioButton)findViewById(R.id.radioMale);  
		radioMale.setChecked(preferences.getBoolean("isMaleChecked", false));
		RadioButton radioFemale = (RadioButton)findViewById(R.id.radioFemale);  
		radioFemale.setChecked(preferences.getBoolean("isFemaleChecked", false));

		CheckBox checkbox = (CheckBox)findViewById(R.id.checkBox1);  
		checkbox.setChecked(preferences.getBoolean("sendChocolate", false));
	}
}