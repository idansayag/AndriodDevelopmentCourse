/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This is a secondary screen which is used
    to hide the first and main Activity. Once this
    secondary Activity is visible, the OnPause()
    method of the main Activity is executed and
    all the form data is saved to the SharedPreferences.
================================================= */
package il.co.practis.sharedpreferences;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class SecondScreen extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second_screen);
	}

	public void killApp(View view) {
		// kills current APP with all its activities
		android.os.Process.killProcess(android.os.Process.myPid());	
	}
}
