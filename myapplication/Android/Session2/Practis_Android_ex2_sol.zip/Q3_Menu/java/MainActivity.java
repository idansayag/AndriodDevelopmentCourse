/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This App uses three types of menu items - 
 	* regular - used to show a toast message
 	* checkbox - used to alternate between background colors
 	* Submenu - used to navigate to different screens
================================================= */
package il.co.practis.menu;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.mymenu, menu);

		return true;
	}


	@Override
	public boolean onOptionsItemSelected(MenuItem item) {

		switch (item.getItemId()) {
		case R.id.showMessage:
			showMessage();
			return true;

		case R.id.useAwfulBackgroundColor:	
			item.setChecked(!item.isChecked());
			setBackgroundColor(item.isChecked());
			return true;

		case R.id.showAbout:
			showAboutScreen();
			return true;

		case R.id.showPictureScreen:
			showPictureScreen();
			return true;

		default:
			return super.onOptionsItemSelected(item);
		}
	}

	private void showPictureScreen() {
		Intent intent = new Intent(this, PictureActivity.class);
		startActivity(intent); 
	}

	private void showAboutScreen() {
		Intent intent = new Intent(this, AboutActivity.class);
		startActivity(intent); 

	}

	private void setBackgroundColor(boolean newCheckedValue) {
		RelativeLayout relativeLayout = (RelativeLayout)findViewById(R.id.mainLayout);

		if (newCheckedValue == true) {
			// use this code in older APIs
			//relativeLayout.setBackgroundColor(Color.RED);

			// this can be used in API >= 16
			GradientDrawable gd = new GradientDrawable(
					GradientDrawable.Orientation.TOP_BOTTOM,
					new int[] {0xff000000,0xffff0000});
			gd.setCornerRadius(0f);

			relativeLayout.setBackground(gd);
		}
		else {
			relativeLayout.setBackgroundColor(Color.WHITE);
		}
	}


	private void showMessage() {
		// we will discuss Context in next classes
		Context context = getApplicationContext();
		Toast toast = Toast.makeText(context, 
				getString(R.string.toast_message),
				Toast.LENGTH_SHORT);

		toast.show();

	}
}