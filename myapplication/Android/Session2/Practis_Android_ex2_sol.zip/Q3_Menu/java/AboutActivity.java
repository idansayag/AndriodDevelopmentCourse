/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This Activity shows an about screen    
================================================= */
package il.co.practis.menu;

import android.app.Activity;
import android.os.Bundle;


public class AboutActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_about);
	}
}
