/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This application is using Intents to activate
    various Android capabilities such as the
    camera or the contact viewer.
================================================= */
package il.co.practis.intentactions;

import java.util.Random;

import android.app.Activity;
import android.app.SearchManager;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

public class MainActivity extends Activity {

	public static final int CAMERA_REQUEST_CODE = 123;	// used to identify Camera request and reply


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}


	/**
	 * Show the information of a random contact
	 * @param view
	 */
	public void performShowRandomContact(View view) {

		// get number of contacts so we can choose a random one
		Cursor cursor =  getContentResolver().query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
		int count = cursor.getCount();

		// generate random contact number
		Random randomGenerator = new Random();
		int randomInt = randomGenerator.nextInt(count) + 1;

		// Prepare Intent to open Contact viewer
		Intent intent = new Intent(Intent.ACTION_VIEW);
		Uri uri = Uri.withAppendedPath(
				ContactsContract.Contacts.CONTENT_URI, 
				randomInt + "");
		intent.setData(uri);

		// Start Intent
		startActivity(intent);	
	}


	/**
	 * Activates the camera so the user can take a picture
	 * @param view
	 */
	public void performTakeCameraSnapshot(View view) {
		// Prepare Camera Intent	
		Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

		// Start Intent	
		startActivityForResult(cameraIntent , CAMERA_REQUEST_CODE);
	}


	/**
	 * Opens Practis' web page
	 * @param view
	 */
	public void performOpenWebPage(View view) {
		// Prepare Intent to open URL
		String url = "http://www.practis.co.il";
		Intent intent = new Intent(Intent.ACTION_VIEW);
		intent.setData(Uri.parse(url));

		// Start Intent	
		startActivity(intent);

	}


	/**
	 * Shows the send SMS message screen with content
	 * @param view
	 */
	public void performSendSMS(View view) {
		// Prepare Intent to open SMS viewer/sender
		Intent smsIntent = new Intent(Intent.ACTION_VIEW);
		smsIntent.setType("vnd.android-dir/mms-sms");
		smsIntent.putExtra("address", "Cows inc.");
		smsIntent.putExtra("sms_body","Mooo!! Mooo!!! Oh yea, and also Moo!");

		// Start Intent
		startActivity(smsIntent);
	}


	/**
	 * Starts a google search of the provided term (assuming it is long enough)
	 * @param view
	 */
	public void performWebSearch(View view) {
		// extract term to search from the form
		EditText editTextTermToSearch = (EditText)findViewById(R.id.editTextSearchTerm);
		String termToSearch = editTextTermToSearch.getText().toString().trim();

		// make sure term to search is long enough
		if (termToSearch.length() < 2) {
			Toast errorMessage = Toast.makeText(this, 
					"Search term is too short",
					Toast.LENGTH_SHORT);
			errorMessage.show();		}
		else {
			// create the new intent
			Intent intent = new Intent(Intent.ACTION_WEB_SEARCH );
			intent.putExtra(SearchManager.QUERY, termToSearch);
			startActivity(intent);
		}
	}


	/**
	 * This handles the result we get back from the camera - it sets the new taken
	 * picture as the background of the form
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// Parse result	
		if (requestCode == CAMERA_REQUEST_CODE && resultCode == RESULT_OK) {
			Bundle extras = data.getExtras();
			Bitmap imageBitmap = (Bitmap) extras.get("data");

			// Set ImageView to contain picture taken
			Drawable drawable = new BitmapDrawable(getResources(),imageBitmap);
			RelativeLayout formBackgroundLayout = (RelativeLayout)findViewById(R.id.relativeLayoutBackground);
			formBackgroundLayout.setBackground(drawable);

		}
	}
}