/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This application is using Intents to pass info
    back and forth between two activities
    
    This is the secondary Activity which gets values
    from the Main Activity and gives the user a
    chance to edit them, and sends the new values
    back to the main activity once the button was
    clicked.
================================================= */
package il.co.practis.intentdatatransfer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class SecondaryActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_secondary);
		
		// set values for EditText fields from Intent extra values
		Bundle extras = getIntent().getExtras(); 
		if (extras != null) { 
			String nameValue = extras.getString("name"); 
			String ageValue = extras.getString("age");
			
			setEditTextValue(R.id.editTextSecondaryName, nameValue);
			setEditTextValue(R.id.editTextSecondaryAge, ageValue);
		}
	}
	
	
	/**
	 * Handles the only button click
	 * @param view
	 */
	public void performClickSecondary(View view) {
		Intent returnIntent = new Intent(); 

		// get current updated values
		String currentName = getEditTextValue(R.id.editTextSecondaryName);
		String currentAge = getEditTextValue(R.id.editTextSecondaryAge);
		
		// Set result additional parameters
		returnIntent.putExtra("name", currentName);
		returnIntent.putExtra("age", currentAge);

		// Set main result value
		setResult(RESULT_OK, returnIntent);

		// Close Activity2
		finish();
	}
	
	
	/**
	 * Returns the String value of the EditText provided by id
	 * @param id
	 * @return
	 */
	private String getEditTextValue(int id) {
		EditText editTextField = (EditText)findViewById(id);
		
		return editTextField.getText().toString();
	}
		
	
	/**
	 * Sets the provided String value to the provided EditText
	 * field (by id)
	 * @param id
	 * @param newValue
	 */
	private void setEditTextValue(int id, String newValue) {
		EditText editTextField = (EditText)findViewById(id);		
		editTextField.setText(newValue);		
	}	
}