/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This application is using Intents to pass info
    back and forth between two activities
    
    This is the main Activity which activates the
    Secondary one.
================================================= */
package il.co.practis.intentdatatransfer;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	
	/**
	 * Handle the click event of the only button we have on this form
	 * @param view
	 */
	public void performClick(View view) {
		Intent intent = new Intent(this, SecondaryActivity.class);

		// get form values
		String currentName = getEditTextValue(R.id.editTextName);
		String currentAge = getEditTextValue(R.id.editTextAge);

		// add values to intent
		intent.putExtra("name", currentName);
		intent.putExtra("age", currentAge);

		// start the secondary activity
		startActivityForResult(intent, 123);
	}


	/**
	 * Returns the String value of the EditText provided by id
	 * @param id
	 * @return
	 */
	private String getEditTextValue(int id) {
		EditText editTextField = (EditText)findViewById(id);

		return editTextField.getText().toString();
	}


	/**
	 * Handles cases where secondary activity returns result
	 */
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == 123) {

			if(resultCode == RESULT_OK){
				// get updated values
				String newName = data.getStringExtra("name");
				String newAge = data.getStringExtra("age");

				// set new values to the form
				setEditTextValue(R.id.editTextName, newName);
				setEditTextValue(R.id.editTextAge, newAge);

			}

			if (resultCode == RESULT_CANCELED) {
				// Handle case where Activity2 cancelled
			}
		}
	}

	
	/**
	 * Sets the provided String value to the provided EditText
	 * field (by id)
	 * @param id
	 * @param newValue
	 */
	private void setEditTextValue(int id, String newValue) {
		EditText editTextField = (EditText)findViewById(id);		
		editTextField.setText(newValue);		
	}
}