/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This is the third screen of this simple 
    multi-Activity APP
================================================= */
package il.co.practis.multiactivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Screen3 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_screen3);
	}
	
    public void gotoScreen1(View view) {
    	Intent intent = new Intent(this, MainActivity.class);
    	startActivity(intent);
    }
    
    public void gotoScreen2(View view) {
    	Intent intent = new Intent(this, Screen2.class);
    	startActivity(intent);
    }
    
}
