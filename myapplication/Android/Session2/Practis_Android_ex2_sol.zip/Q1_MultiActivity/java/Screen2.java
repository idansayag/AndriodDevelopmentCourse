/* ===============================================
    This code was written by Yoav Levenson
    As part of Practis Android development course

    This is the second screen of this simple 
    multi-Activity APP
================================================= */
package il.co.practis.multiactivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Screen2 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_screen2);
	}
	
    public void gotoScreen1(View view) {
    	Intent intent = new Intent(this, MainActivity.class);
    	startActivity(intent);
    }
    
    public void gotoScreen3(View view) {
    	Intent intent = new Intent(this, Screen3.class);
    	startActivity(intent);
    }
}
